import React from 'react'

export default function NotFound() {
  return (
    <div>
        <img 
            src="https://picturesofmaidenhead.files.wordpress.com/2019/01/image-not-found.jpg?w=1620"
            alt=''
            className='img img-fluid'
        />
    </div>
  )
}